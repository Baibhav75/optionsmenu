package com.example.optionsmenu

import android.content.Context
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast

class Menu {

    fun showMenu(context: Context,view: View){

        val pop= PopupMenu(context,view)
        pop.inflate(R.menu.menu)

        pop.setOnMenuItemClickListener {
            when(it!!.itemId){
                R.id.edit -> {
                    Toast.makeText(context, "Clicked Edit", Toast.LENGTH_LONG).show()
                    true
                }
                R.id.delete -> {
                    Toast.makeText(context, "Clicked Deleted", Toast.LENGTH_LONG).show()
                    true
                }
                R.id.share -> {
                    Toast.makeText(context, "Clicked Shared", Toast.LENGTH_LONG).show()
                    true
                }
                else -> false
            }
        }

        try {

            val filedMpopup =PopupMenu::class.java.getDeclaredField("mPopup")
            filedMpopup.isAccessible =true
            val mPopup =filedMpopup.get(pop)
            mPopup.javaClass
                .getDeclaredMethod("setFoeceShowIcon",Boolean::class.java)
                .invoke(mPopup,true)
        } catch (e:Exception){

        }finally {
            pop.show()
        }
    }
}